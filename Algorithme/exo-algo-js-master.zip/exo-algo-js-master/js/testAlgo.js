/* ici on va pouvoir tester des algos en JS */
/* pour demander une valeur à l'utilisateur : var a = Lit("Mess") */
/* pour afficher une valeur à l'écran : Affiche("Mess") */