Thanks for downloading this template!

Template Name: Kelvin
Template URL: https://templatemag.com/kelvin-bootstrap-resume-template/
Author: TemplateMag.com
License: https://templatemag.com/license/